package pl.sda.buymemommy.model;

public enum Gender {
    GIRL, BOY, BOTH;
}
