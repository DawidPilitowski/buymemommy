package pl.sda.buymemommy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuymemommyApplication {

    public static void main(String[] args) {
        SpringApplication.run(BuymemommyApplication.class, args);
    }
}
